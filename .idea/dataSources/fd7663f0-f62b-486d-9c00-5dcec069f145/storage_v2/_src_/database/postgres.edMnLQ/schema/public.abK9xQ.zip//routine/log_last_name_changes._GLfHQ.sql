create function log_last_name_changes() returns trigger
    language plpgsql
as
$$
begin
    if new.last_name <> old.last_name
    then
        insert into mentor_audit(mentor_id, last_name, changed_on) values (old.id, old.last_name, now());
    end if;

    return new;

end;


$$;

alter function log_last_name_changes() owner to postgres;

