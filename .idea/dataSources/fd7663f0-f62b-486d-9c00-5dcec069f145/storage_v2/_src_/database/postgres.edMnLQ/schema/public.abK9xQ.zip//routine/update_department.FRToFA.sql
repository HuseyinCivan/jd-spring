create procedure update_department(emp_id integer)
    language plpgsql
as
$$
declare
begin
    update employees set department = 'Toys' where employee_id = emp_id;
    commit;

end

$$;

alter procedure update_department(integer) owner to postgres;

